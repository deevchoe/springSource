package pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JulyExam3Application {

	public static void main(String[] args) {
		SpringApplication.run(JulyExam3Application.class, args);
	}

}
