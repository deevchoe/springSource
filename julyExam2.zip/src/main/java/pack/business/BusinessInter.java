package pack.business;

public interface BusinessInter {
	void printGogek();
}
