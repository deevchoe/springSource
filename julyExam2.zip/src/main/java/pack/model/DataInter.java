package pack.model;

import java.util.List;

public interface DataInter {
	List<GogekDto> selectDataAll();
}